# YOUSAF-BALOCH-MD v2.0.0

## 🚀 Advanced WhatsApp Bot with 500+ Commands

Created by **Muhammad Yousaf Baloch**

---

## 📋 Features

- ✅ **500+ Commands** organized in 30+ plugin files
- ✅ **Rule of 5 Grouping** - Each file contains exactly 5 commands
- ✅ **Multi-User Access** - Deployer-level admin system
- ✅ **3-Step Warning System** - Auto-kick after 3 warnings
- ✅ **YouTube Downloader** - Video, Audio, Play, Bayan, Song
- ✅ **Social Media Downloaders** - TikTok, Facebook, Instagram, CapCut, Inshot
- ✅ **AI Features** - ChatGPT, Gemini, DALL-E, Image Generation
- ✅ **Islamic Commands** - Quran, Hadith, Prayer Times, Islamic Info
- ✅ **Group Management** - Kick, Ban, Mute, Anti-Link, Anti-Spam
- ✅ **Economy System** - Coins, Daily Rewards, Shop, Leaderboard
- ✅ **Games** - Dice, Coin Flip, Quiz, Math Challenge, Tic Tac Toe
- ✅ **Sticker Tools** - Create, Steal, Text-to-Sticker
- ✅ **Utility Tools** - Calculator, Weather, QR Code, Screenshot
- ✅ **Sports Updates** - Cricket, Football, PSL Live Scores

---

## 📁 File Structure

```
YOUSAF-BALOCH-MD/
├── config.js              # Core configuration
├── index.js               # Main bot entry point
├── package.json           # Dependencies
├── .env.example           # Environment variables template
├── INDEX_PATCH_loadPlugins.js  # Plugin loader patch
├── lib/
│   └── utils.js           # Utility functions
├── plugins/
│   ├── ai_v1.js           # GPT, ChatGPT, Gemini, Bing, Blackbox
│   ├── ai_v2.js           # Imagine, DALL-E, BG Remove, Upscale, OCR
│   ├── ai_v3.js           # Translate, TTS, Roman Urdu, Sentiment, Code
│   ├── ai_v4.js           # Doctor, Lawyer, Homework, Resume, Khuwab
│   ├── apk_tools_v1.js    # APK, Mod APK, PlayStore, APK Mod, APK DL
│   ├── auto_v1.js         # Auto Status, Auto Read, Auto Reply, Anti-VV, Auto Like
│   ├── economy_v1.js      # Balance, Daily, Work, Shop, Leaderboard
│   ├── fun_v1.js          # Joke, Quote (2 commands - remainder)
│   ├── game_v1.js         # Dice, Coin, Quiz, Math, Tic Tac Toe
│   ├── group_v1.js        # Kick, Add, Promote, Demote, Ban
│   ├── group_v2.js        # Tag All, Hide Tag, Admins, Members, Link
│   ├── group_v3.js        # Anti Link, Anti Abuse, Anti Delete, Anti VV, Warn
│   ├── group_v4.js        # Unwarn, Warn List, Banned List, Ghost, Activity
│   ├── group_v5.js        # Settings, Mute, Unmute, Leave, Invite
│   ├── group_v6.js        # Auto Sticker, Auto Bio, Poll, Unban (4 commands - remainder)
│   ├── islamic_v1.js      # Quran, Ayat, Hadith, Dua, Prayer
│   ├── islamic_v2.js      # Prayer Time, Hijri, Asma, Names, Tafsir
│   ├── islamic_v3.js      # Zakat, Hajj (2 commands - remainder)
│   ├── main_v1.js         # Alive, Ping, Runtime, Info, Menu
│   ├── owner_v1.js        # Broadcast, Block, Unblock, Restart, Eval
│   ├── social_v1.js       # TikTok, Facebook, Instagram, CapCut, Inshot
│   ├── sports_v1.js       # Cricket, Live, Score, PSL, Football
│   ├── sticker_v1.js      # Sticker, Take, Steal, TTP
│   ├── tools_v1.js        # Calculator, Weather, QR, Shortlink, Screenshot
│   └── yt_tools_v1.js     # Video, Audio, Play, Bayan, Song
```

---

## 🛠️ Installation

### Prerequisites
- Node.js 18+
- npm or yarn

### Steps

1. **Clone the repository**
```bash
git clone https://github.com/musakhanbaloch03-sad/YOUSAF-BALOCH-MD.git
cd YOUSAF-BALOCH-MD
```

2. **Install dependencies**
```bash
npm install
```

3. **Configure environment variables**
```bash
cp .env.example .env
# Edit .env with your settings
```

4. **Start the bot**
```bash
npm start
```

---

## ⚙️ Environment Variables

| Variable | Description | Required |
|----------|-------------|----------|
| `SESSION_ID` | WhatsApp session ID | Yes |
| `PREFIX` | Bot command prefix (default: .) | No |
| `MODE` | Bot mode (public/private) | No |
| `DEPLOYER_NUMBER` | Deployer phone number | Yes |
| `GEMINI_API_KEY` | Gemini AI API key | No |
| `GROQ_API_KEY` | Groq AI API key | No |
| `REMOVEBG_API_KEY` | Remove.bg API key | No |
| `RAPIDAPI_KEY` | RapidAPI key | No |
| `MONGODB_URI` | MongoDB connection string | No |

---

## 📱 Commands

### AI Commands
- `.gpt <question>` - Chat with GPT
- `.gemini <question>` - Chat with Gemini
- `.imagine <description>` - Generate AI image
- `.dalle <description>` - DALL-E image generation
- `.translate <text>` - Translate text
- `.tts <text>` - Text to speech

### Download Commands
- `.video <url/query>` - Download YouTube video
- `.audio <url/query>` - Download YouTube audio
- `.play <song>` - Play music
- `.bayan <scholar>` - Download Islamic bayan
- `.tiktok <url>` - Download TikTok video
- `.fb <url>` - Download Facebook video
- `.insta <url>` - Download Instagram media

### Group Commands
- `.kick @user` - Kick user from group
- `.add <number>` - Add user to group
- `.promote @user` - Promote to admin
- `.demote @user` - Demote from admin
- `.tagall` - Tag all members
- `.hidetag <message>` - Hidden tag all
- `.antilink on/off` - Toggle anti-link
- `.warn @user` - Warn user

### Islamic Commands
- `.quran <surah>` - Read Quran
- `.hadith` - Random hadith
- `.prayer <city>` - Prayer times
- `.dua` - Daily dua

### Economy Commands
- `.balance` - Check wallet
- `.daily` - Claim daily reward
- `.work` - Work to earn coins
- `.shop` - Buy items
- `.leaderboard` - Top players

### Game Commands
- `.dice` - Roll dice
- `.coin` - Flip coin
- `.quiz` - Quiz game
- `.math` - Math challenge
- `.tictactoe start` - Play Tic Tac Toe

### Sticker Commands
- `.sticker` - Create sticker (reply to image)
- `.take <pack>` - Steal sticker with custom pack
- `.ttp <text>` - Text to sticker

### Tool Commands
- `.calc <expression>` - Calculator
- `.weather <city>` - Weather info
- `.qr <text>` - Generate QR code
- `.shortlink <url>` - Shorten URL
- `.screenshot <url>` - Website screenshot

### Owner Commands
- `.broadcast <message>` - Broadcast to all groups
- `.block @user` - Block user
- `.unblock @user` - Unblock user
- `.restart` - Restart bot
- `.eval <code>` - Evaluate JavaScript

---

## 👑 Owner Information

- **Name:** Muhammad Yousaf Baloch
- **Phone:** +92 371 0636110
- **YouTube:** https://www.youtube.com/@Yousaf_Baloch_Tech
- **TikTok:** https://tiktok.com/@loser_boy.110
- **Channel:** https://whatsapp.com/channel/0029Vb3Uzps6buMH2RvGef0j
- **GitHub:** https://github.com/musakhanbaloch03-sad

---

## 📜 License

MIT License - See LICENSE file for details

---

## 🙏 Credits

- **Baileys** - WhatsApp Web API
- **All contributors** - For their amazing work

---

## ⚠️ Disclaimer

This bot is for educational purposes only. Use at your own risk. The developer is not responsible for any misuse of this bot.

---

**© 2026 YOUSAF-BALOCH-MD - Created by Muhammad Yousaf Baloch**
